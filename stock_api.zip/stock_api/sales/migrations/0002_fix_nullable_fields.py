"""
Migration 0002 — Corrections des champs nullable
- Discount.product : null=True, blank=True (réduction globale possible)
- ActivityLog.worker : null=True, blank=True (clients/super_admin peuvent avoir des logs)
NOTE: limit_choices_to est ORM-only, pas une contrainte SQL → pas besoin de migration pour ça.
"""
from django.db import migrations
import django.db.models.deletion
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        ('sales', '0001_initial'),
    ]

    operations = [
        # Discount.product nullable (réduction globale sans produit spécifique)
        migrations.AlterField(
            model_name='discount',
            name='product',
            field=django.db.models.fields.related.ForeignKey(
                blank=True,
                null=True,
                help_text='Produit affecté par la réduction (null = tous les produits)',
                on_delete=django.db.models.deletion.CASCADE,
                related_name='discounts',
                to='sales.product',
            ),
        ),
        # ActivityLog.worker nullable (clients/super_admin peuvent avoir des logs)
        migrations.AlterField(
            model_name='activitylog',
            name='worker',
            field=django.db.models.fields.related.ForeignKey(
                blank=True,
                null=True,
                help_text="Utilisateur qui a effectué l'action",
                on_delete=django.db.models.deletion.CASCADE,
                related_name='activity_logs',
                to=settings.AUTH_USER_MODEL,
            ),
        ),
    ]
